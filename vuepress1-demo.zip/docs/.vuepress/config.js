module.exports = {
  // 打包路径
  base: '',
  // 标题
  title: '1cool',
  // 介绍
  description: '- . -',
  // 主题配置
  themeConfig: {
    nav: [
      { text: '首页', link: '/' },
      { text: '工具', link: '/gongJu/c11' },
      { text: 'External', link: 'https://google.com' },
    ],
    sidebar: {
      title: '工具',   // 必要的
      path: '/gongJu/',      // 可选的, 标题的跳转链接，应为绝对路径且必须存在
      collapsable: false, // 可选的, 默认值是 true,
      sidebarDepth: 1,    // 可选的, 默认值是 1
      children: [
        '/gongJu',
        '/gongJu/c11',
        '/gongJu/c22',
      ]
    },
  }
}